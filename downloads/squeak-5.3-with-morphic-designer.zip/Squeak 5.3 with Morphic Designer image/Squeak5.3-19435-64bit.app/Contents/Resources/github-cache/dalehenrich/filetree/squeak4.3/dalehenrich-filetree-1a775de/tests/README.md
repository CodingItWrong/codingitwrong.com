## Structure

The **testRepositories** directory contains sample packages that are used by the tests.

