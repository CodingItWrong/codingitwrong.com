I'm a notification to say tonel writer that he should ignore a section. 
This typically happens on a MCClassTraitDefinition, because it will be managed on MCTraitDefinition.

(see TonelWriter>>typeOf:)