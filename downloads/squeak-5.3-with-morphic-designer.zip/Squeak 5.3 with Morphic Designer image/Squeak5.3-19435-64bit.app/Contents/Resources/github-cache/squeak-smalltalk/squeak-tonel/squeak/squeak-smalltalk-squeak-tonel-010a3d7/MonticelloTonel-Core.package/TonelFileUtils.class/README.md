I declare file operations to be used in tonel. 
I'm necesary because tonel is meant to be portable, and different dialects have different ways of dealing with file systems. 