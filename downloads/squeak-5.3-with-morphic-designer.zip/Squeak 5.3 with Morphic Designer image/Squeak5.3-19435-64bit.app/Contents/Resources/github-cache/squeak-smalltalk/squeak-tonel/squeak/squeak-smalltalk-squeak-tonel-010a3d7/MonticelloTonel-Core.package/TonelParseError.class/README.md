I'm a parsing error. 
I happen whenever the parsing of a tonel file is broken in someway.