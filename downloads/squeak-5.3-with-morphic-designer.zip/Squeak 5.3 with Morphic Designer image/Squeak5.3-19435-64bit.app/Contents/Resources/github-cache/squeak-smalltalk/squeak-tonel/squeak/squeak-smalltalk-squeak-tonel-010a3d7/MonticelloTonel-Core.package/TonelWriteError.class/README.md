I'm a writing error.
I happen whenever an unrecoverable problem was encountered during writing of tonel.