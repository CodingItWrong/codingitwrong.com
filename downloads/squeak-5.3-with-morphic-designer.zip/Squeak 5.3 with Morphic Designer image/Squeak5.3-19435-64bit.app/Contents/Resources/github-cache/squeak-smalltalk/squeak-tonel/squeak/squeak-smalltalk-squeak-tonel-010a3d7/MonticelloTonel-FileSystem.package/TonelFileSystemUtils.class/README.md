I'm a file utils implementation who works with FileSystem framework.
Pharo should use me.