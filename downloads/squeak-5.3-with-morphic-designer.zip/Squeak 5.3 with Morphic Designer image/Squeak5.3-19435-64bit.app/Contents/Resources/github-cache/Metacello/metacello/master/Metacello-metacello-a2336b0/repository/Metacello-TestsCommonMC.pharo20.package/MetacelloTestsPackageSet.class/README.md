This class is used to speed up Metacello tests.
