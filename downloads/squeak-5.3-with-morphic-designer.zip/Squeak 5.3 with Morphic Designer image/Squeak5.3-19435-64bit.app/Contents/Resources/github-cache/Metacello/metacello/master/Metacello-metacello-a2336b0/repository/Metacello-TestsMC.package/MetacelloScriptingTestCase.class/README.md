##MetacelloScriptingTestCase

**MetacelloScriptingTestCase** implements the test suite that validates the **Metacello** scripting API.
